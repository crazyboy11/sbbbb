rocks_trees = {
   { name = [[system]], root = [[/home/ubuntu/workspace/telegram-bot/.luarocks]] }
}
