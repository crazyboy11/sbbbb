do local _ = {
  disabled_channels = {},
  enabled_plugins = {
    "Echo",
    "Get",
    "google",
    "gps",
    "location",
    "Set",
    "Link",
    "AntiLink",
    "Chat",
    "channelmod",
    "Plugins",
    "Broadcast",
    "Welcome",
    "Wai",
    "Tagall",
    "Term",
    "Spammer",
    "Media",
    "Info",
    "Filtering",
    "FileManager",
    "Feedback",
    "Realm",
    "Gpmod",
    "invite",
    "anti-flood",
    "channelmod",
    "Send",
    "T2i",
    "AntiChat",
    "Cleaner",
    "Id",
    "weather",
    "Stats",
    "Images",
    "Kickme",
    "Insudo",
    "Support",
    "Invite",
    "AntiTag"
  },
  moderation = {
    data = "data/moderation.json"
  },
  sudo_users = {
    164565909
  }
}
return _
end